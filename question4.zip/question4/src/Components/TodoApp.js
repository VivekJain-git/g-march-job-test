import React, { useState, useEffect } from "react";
import AddTodo from "./AddTodo";
import Filter from "./Filter";
import TodoList from "./TodoList";
import "./styles.css";

const TodoApp = () => {
  const [todos, setTodos] = useState([]);
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(false);
  const [hasFetchedOnce, setHasFetchedOnce] = useState(false); // Track fetch button click

  // Sync todos with localStorage every time they change
  useEffect(() => {
    const savedTodos = JSON.parse(localStorage.getItem("todos"));
    if (savedTodos) {
      setTodos(savedTodos); // Load saved todos if available in localStorage
      setHasFetchedOnce(true); // Mark as fetched since we loaded from localStorage
    }
  }, []);

  // Update localStorage whenever todos change
  useEffect(() => {
    if (todos.length > 0) {
      localStorage.setItem("todos", JSON.stringify(todos)); // Save updated todos to localStorage
    }
  }, [todos]);

  // Add a new task
  const addTask = (todoText) => {
    if (!todoText.trim()) return;

    const newTask = { id: Date.now(), todo: todoText, completed: false, userId: 1 }; // userId is a placeholder

    setTodos((prevTodos) => [...prevTodos, newTask]);
  };

  // Toggle task completion status for a specific task
  const toggleTask = (taskId) => {
    setTodos((prevTodos) =>
      prevTodos.map((todo) =>
        todo.id === taskId
          ? { ...todo, completed: !todo.completed }
          : todo
      )
    );
  };

  // Delete a task
  const deleteTask = (taskId) => {
    setTodos((prevTodos) => prevTodos.filter((todo) => todo.id !== taskId));
  };

  // Filter tasks based on their status
  const filteredTodos = todos.filter((todo) => {
    if (filter === "completed") return todo.completed;
    if (filter === "pending") return !todo.completed;
    return true;
  });

  // Fetch tasks from the API on button click
  const fetchTasksFromAPI = () => {
    setLoading(true); // Show loading state

    fetch("https://dummyjson.com/todos")
      .then((res) => res.json())
      .then((data) => {
        setTodos(data.todos); // Update state with fetched tasks
        setLoading(false); // Hide loading state
        setHasFetchedOnce(true); // Set flag to true after fetching tasks
      })
      .catch((error) => {
        console.error("Error fetching todos:", error);
        setLoading(false); // Hide loading state if there's an error
      });
  };

  // Fetch button should only be visible when no tasks are in localStorage and haven't been fetched
  const shouldShowFetchButton = !hasFetchedOnce && todos.length === 0;

  return (
    <div className="todo-container">
      <h1>📝 To-Do List</h1>

      {/* AddTodo component visible even before data is fetched */}
      <AddTodo addTask={addTask} />
      
      {/* Show the Fetch Button only if it hasn't been clicked before */}
      {shouldShowFetchButton && (
        <button onClick={fetchTasksFromAPI} className="fetch-btn">
          {loading ? "Loading..." : "Fetch Tasks from API"}
        </button>
      )}

      {/* Loading indicator when tasks are being fetched */}
      {loading && <p>Loading tasks...</p>}
      
      <Filter setFilter={setFilter} />
      <TodoList todos={filteredTodos} toggleTask={toggleTask} deleteTask={deleteTask} />
    </div>
  );
};

export default TodoApp;
