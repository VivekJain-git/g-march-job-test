import React from "react";

const TodoItem = ({ todo, toggleTask, deleteTask }) => (
  <li className="todo-item">
    <span onClick={() => toggleTask(todo.id)} className={todo.completed ? "completed" : ""}>
      {todo.todo}
    </span>
    {todo.completed && <span className="completed-text"> - Task Completed</span>}
    <button className="delete-btn" onClick={() => deleteTask(todo.id)}>❌</button>
  </li>
);

export default TodoItem;
